# Kraków Transport

Statyczna strona gotowa do publikacji na GitHub Pages.

## Uruchomienie
Otwórz `index.html` albo opublikuj repozytorium przez GitHub Pages (Settings → Pages → Deploy from a branch).

## Pliki
- `index.html` – strona główna
- `galeria.html`, `tabor.html`, `regulamin.html`, `administracja.html`, `linie-mapa.html` – podstrony
- `assets/js/main.js` – menu mobilne, wybór języka i interakcje
- `assets/js/map.js` – mapa Leaflet i przykładowe trasy
- `assets/img/` – miejsce na własne logo i zdjęcia

## Własne materiały
Podmień adresy zdjęć w znacznikach `<img>` na własne pliki, np. `assets/img/autobus-1.jpg`. Logo możesz dodać jako `assets/img/logo.png`.
Kafelki taboru prowadzą do `autobusy.html`, `tramwaje.html`, `pojazdy-techniczne.html` i `pozostale.html` – utwórz te pliki samodzielnie lub zmień linki w `tabor.html`.

Mapa korzysta z Leaflet i OpenStreetMap przez CDN, więc do działania online potrzebne jest połączenie z internetem. Strona nie wymaga backendu ani procesu budowania.
