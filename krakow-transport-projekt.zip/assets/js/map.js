(function(){
 if(typeof L==='undefined')return;
 const map=L.map('transport-map',{scrollWheelZoom:false}).setView([50.0614,19.9366],12);
 L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap'}).addTo(map);
 const routes=[
  {n:'4',c:'#1769ff',p:[[50.0672,19.9450],[50.0647,19.9368],[50.0614,19.9366],[50.0580,19.9490],[50.0750,20.0400]]},
  {n:'8',c:'#e05c83',p:[[50.0870,19.8940],[50.0750,19.9100],[50.0614,19.9366],[50.0450,19.9480],[50.0200,19.9370]]},
  {n:'52',c:'#13a58b',p:[[50.0100,19.8950],[50.0300,19.9100],[50.0614,19.9366],[50.0750,19.9800],[50.0900,20.0200]]},
  {n:'179',c:'#e19a31',p:[[50.0100,19.9600],[50.0350,19.9500],[50.0614,19.9366],[50.0670,19.9450]]}
 ];
 routes.forEach(r=>{L.polyline(r.p,{color:r.c,weight:5,opacity:.8}).addTo(map).bindPopup('<strong>Linia '+r.n+'</strong><br>Przykładowy przebieg')});
 L.marker([50.0614,19.9366]).addTo(map).bindPopup('<strong>Kraków – centrum</strong>');
})();
